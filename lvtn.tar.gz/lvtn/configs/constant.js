module.exports = {
    PORT: process.env.PORT || 8080,
    APPNAME: "NNCNC",
    ROUTE: {
        HOME: "/",
        CATEGORY: {
            V8080IEW: "/category",
            ADD: "/category/add",
            UPDATE: "/category/update"
        },
        TENTANT: {
            VIEW: "/tentant",
            ADD: "/tentant/add",
            UPDATE: "/tentant/update",
            DEACTIVE: "/tentant/deactive",
            GET: "/tentant/get"
        },
        SITE: {
            VIEW: "/site",
            ADD: "/site/add"
        },
        PAGE: {
            VIEW: "/page",
            ADD: "/page/add"
        },
        ARTICLE: "/article",
        API: {
            TENTANT: {
                GET: "/api/tentant/get",
            },
            CATEGORY: {
                GET: "/api/category/get",
            },
            SITE: {
                GET: "/api/site/get",
            },
            PAGE: {
                GET: "/api/page/get"
            },
            ARTICLE: "/api/article/get"
        }
    },
    MQTT: {
        "SERVER": "m13.cloudmqtt.com",
        "USER": "xcrlhzwu",
        "PASSWORD": "3xvy_pbUYmf-",
        "PORT": "10061",
        "SSLPORT": 20061,
        "WSWORD": 30061
    }
}