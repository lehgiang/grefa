module.exports = {
  'secret': 'devdacticIsAwesome',
  'database': 'mongodb://localhost/NNCNC'
};