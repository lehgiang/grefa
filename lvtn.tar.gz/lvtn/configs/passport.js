var JwtStrategy = require('passport-jwt').Strategy;

var passport = require('passport')
, LocalStrategy = require('passport-local').Strategy;
var jwt         = require('jwt-simple');

// load up the user model
var User = require('../app/models/user');
var SNode = require('../app/models/node');
var config = require('../configs/database'); // get db config file

module.exports = function(passport) {

  passport.serializeUser(function(user, done) {
   done(null, user.id);
 });

  passport.deserializeUser(function(id, done) {
   User.findById(id, function(err, user) {
     done(err, user);
   });
 });
  passport.use('signin', new LocalStrategy({
    usernameField : 'username',
    passwordField : 'password',
    passReqToCallback: true
  },
  function(req, username, password, done) {
   // console.log('passport');
   User.findOne({
    name: username

  }, function(err, user) {
    if (err) {
      return done(null, false, { message: 'Incorrect username.' });
    }

    if (!user) {
      return done(null, false, {message:'ERROR username'});
    } else {
     user.comparePassword(password, function (err, isMatch) {
      if (isMatch && !err) {
        var token = jwt.encode(user, config.secret);
        expiresInMinutes: 1440 // expires in 24 hours
        return done(null, user);
      } else {
              //  console.log("failed");
              return done(null, false, {message:'ERROR'});
            }
          });
   }
 });
 }));
};