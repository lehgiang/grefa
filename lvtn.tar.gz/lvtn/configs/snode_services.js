var SNode = require('../app/models/node');
var Season   = require(__server + '/models/SeasonNode');

module.exports = {
	getSNode: function(user, callback) {
		var listSensorNode = SNode.find({'macPi':user.macPi}).select('sensor_id');
        listSensorNode.exec(function (err, snode) {
          if (err) return handleError(err);
          callback(snode);
        })
	},
	getSeason: function(user, callback) {
		var listSeSeason = Season.find({'macPi':user.macPi, active:true});
        listSeSeason.exec(function (err, season) {
          if (err) return handleError(err);
          callback(season);
        })
	}
}
