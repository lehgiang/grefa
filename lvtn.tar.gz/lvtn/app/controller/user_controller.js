import passport from 'passport';
import passportLocal from 'passport-local';
import passwordHash from 'password-hash';
import multer from 'multer';
import mimeType from 'mime-types';
import fs from 'fs';

const LocalStrategy = passportLocal.Strategy, 
Users = require(__models + "user_model"),
userService = require(__services + "user_service");

var storage =   multer.diskStorage({
	destination: function (req, file, callback) {
		var dir = './public/uploads/' + req.user._id;
		if (!fs.existsSync(dir)){
			fs.mkdirSync(dir);
		}
		callback(null, dir + '/');
	},
	filename: function (req, file, callback) {
		callback(null, file.fieldname + '-' + Date.now() + "." + mimeType.extension(file.mimetype));
	}
});

var upload = multer({ 
	storage : storage,
}).single("avatar");


passport.serializeUser(function(user, done) {
	done(null, user._id);
});

passport.deserializeUser(function(id, done) {
	Users.findById(id, function(err, user) {
		done(err, user);
	});
});


passport.use('signup', new LocalStrategy({
	passReqToCallback: true
},
function(req, username, password, done) {
	process.nextTick(function() {
		Users.findOne({'username':username}, (err, user) => {
			if (err){
				console.log(ERROR.ERR_UNKNOWN + ': ' + err);
				return done(err);
			}
			if (user) {
				console.log(ERROR.ERR_USER_ALREADY_EXITS);
				return done(null, false, {message: ERROR.ERR_USER_ALREADY_EXITS });
			} else {
				var newUser = new Users();
				newUser.username = username;
				newUser.password = passwordHash.generate(password);
				newUser.email = req.body.email;
				newUser.avatar = CONSTANT.DEFAULT_AVATAR;
				newUser.save(function(err) {
					if (err){
						console.log(ERR_USER_CREATED_FAILED + ': ' + err);  
						throw err;  
					}
					console.log(CONSTANT.MESSAGE.SIGNUP_SUCCESS);    
					return done(null, newUser);
				});
			}
		});
	});
}));

passport.use('signin', new LocalStrategy({
	passReqToCallback: true
},
function(req, username, password, done) {
	process.nextTick(function() {
	      User.findOne({
	      name: req.body.uname
	    }, function(err, user) {
	      if (err) throw err;

	      if (!user) {
	        return done(null, false, {message:'ERROR.ERR_USERNAME_OR_PASSWORD_INCORRECT'});
	      } else {
	        console.log("user: ",user);
	         // check if password matches
	         user.comparePassword(req.body.psw, function (err, isMatch) {
	          if (isMatch && !err) {
	            // if user is found and password is right create a token
	            var token = jwt.encode(user, config.secret);
	            console.log("token: ",token);
	            
	            var data = {user,data};
	            //expiresInMinutes: 1440 // expires in 24 hours
	            return done(null, user);
	            

	          } else {
	            return done(null, false, {message:'ERROR.ERR_USERNAME_OR_PASSWORD_INCORRECT'});
	          }
	        });
	       }
	     });
		/*Users.findOne({username:username}, (err, user) => {
			if (err){
				console.log(ERROR.ERR_UNKNOWN + err);
				return done(err);
			}
			if (user) {
				if (passwordHash.verify(password, user.password)) {
					console.log(CONSTANT.MESSAGE.SIGNIN_SUCCESS);
					return done(null, user);
				} else {
					console.log(ERROR.ERR_PASSWORD_INCORRECT);
				}
				return done(null, false, {message:ERROR.ERR_PASSWORD_INCORRECT});
			} 
			return done(null, false, {message:ERROR.ERR_USERNAME_OR_PASSWORD_INCORRECT});
		});*/
	});
}));

function getUserById(req, res){
	userService.getUserById(req.query.id).then(data => {
		res.json(data);
	}).catch(err => {
		console.log(err);
	});
}

function logout(req, res) {
	req.logout();
	res.redirect(CONSTANT.ROUTE.HOME);
}

function updateInfo(req, res){
	var data = req.body;
	Users.findById(data.userId, function(err, user) {
		user.email = data.email;
		user.name = data.lastname + "|" + data.firstname;
		user.phone = data.phone;
		user.gender = data.gender
		user.save(function(err) {
			if (err){
				console.log(ERROR.ERR_UNKNOWN); 
				throw err;  
			}
			console.log(CONSTANT.MESSAGE.UPDATE_INFO_SUCCESS);
			//req.flash("message", CONSTANT.MESSAGE.UPDATE_INFO_SUCCESS);
			res.redirect(VIEW.DASHBOARD);
		});
	});
}

function changeAvatar(req, res){
	upload(req , res,function(err) {
		if(err) {
			return res.end(ERROR.ERR_UPLOAD_FILE + err);
		}
		Users.findById(req.body.userId, function(err, user) {
			var filePath = req.file.destination + req.file.filename;
			filePath = filePath.substr(filePath.indexOf("/") + 1, filePath.length);
			filePath = filePath.substr(filePath.indexOf("/") + 1, filePath.length);
			user.avatar = filePath;
			user.save(function(err){
				if (err){
					console.log(ERROR.ERR_UNKNOWN);  
					throw err;  
				}
				console.log(CONSTANT.MESSAGE.UPLOAD_AVATAR_SUCCESS);
			//	req.flash("message", CONSTANT.MESSAGE.UPLOAD_AVATAR_SUCCESS);
				res.redirect(VIEW.DASHBOARD);
			});
		});
	});
}

function getUser(req, res) {
	userService.getUser(req.query).then(users => {
		res.json(users);
	}).catch(err => {
		console.log(err);
	});
}



module.exports = {
	getUserById,
	getUser,
	updateInfo : updateInfo,
	changeAvatar: changeAvatar,
	logout : logout
}
