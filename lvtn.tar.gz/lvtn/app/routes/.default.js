var snodeService = require(__config + '/snode_services');

module.exports = (app) => {
  app.get("/login", function(req, res) {
    res.render("login/index");
  });
  app.get('/logout', function(req, res){
    req.logout();
    res.redirect('/');
  });

  
  app.get("/add/sensor", isLoggedIn ,function(req, res) {
    var status = req.query.status;
    console.log('status: ', status);
    res.render("add.snode/index",{status:status,user:req.user});
  });
  
  app.get("/admin/routing",isLoggedIn, function(req, res) {
    res.render("admin/pages/routing");
  });

   app.get("/home",isLoggedIn,function(req,res) {
      snodeService.getSeason(req.user, function(season) {
        req.user.season = season;
        console.log('user:',req.user)
        res.render("home/index", { user: req.user, season: season,season_id:req.params});       
      })
 
  });
   app.get('/season/:season_id',isLoggedIn,function(req,res) {
      snodeService.getSeason(req.user, function(season) {
        req.user.season = season;
        res.render("home/index", { user: req.user, season: season,season_id:req.params.season_id});
      })
 
  });
  
}
function isLoggedIn(req, res, next) {
  backURL=req.header('Referer') || '/';

  // nếu người dùng đã đăng nhập thì tiếp tục thực hiện
  if (req.isAuthenticated())
  return next();
  // ngược lại điều hướng về đăng nhập.
  res.redirect('/login');
}