require('../../global');
var passport  = require('passport');
var express     = require('express');
var User        = require(__server + '/models/user'); // get the mongoose model
var SNode        = require(__server + '/models/node'); // get the mongoose model
var SeasonNode   = require(__server + '/models/SeasonNode');
var config      = require(__root+'/configs/database'); // get db config file
var jwt         = require('jwt-simple');
var mqtt    = require('mqtt');


require(__config+'passport')(passport);
// bundle our routes

module.exports = (app) => {
  var apiRoutes = express.Router();
  app.get('/a', function(req, res) {
    res.send('Hello word');
  });

  // create a new user account (POST http://localhost:8080/api/signup)
  apiRoutes.post('/signup', function(req, res) {
    if (!req.body.name || !req.body.password || !req.body.macPi ) {
      res.json({success: false, msg: 'Please pass name and password.'});
    } else {
      var newUser = new User({
        name: req.body.name,
        password: req.body.password,
        macPi: req.body.macPi
      });
      // save the user 
      newUser.save(function(err) {
        if (err) {
          return res.json({success: false, msg: 'Username already exists.'});
        }
        res.json({success: true, msg: 'Successful created new user.'});
      });
    }
  });

  //create a new season node (POST http://localhost:8080/api/add/season)
  apiRoutes.post('/add/season', function(req, res) {
    if (!req.body.active || 
      !req.body.active_start || 
      !req.body.active_end || 
      !req.body.name|| 
      !req.body.season_id || 
      !req.body._id || 
      !req.body.macPi) {
      res.json({success: false, msg: 'Please try to again.'});
  } else {
    var seasonNode = new SeasonNode({
      active:req.body.active, 
      active_start:req.body.active_start,  
      active_end:req.body.active_end,
      name:req.body.name,
      season_id:req.body.season_id,
      _id:req.body._id,
      macPi:req.body.macPi
    });
    console.log(seasonNode);
    seasonNode.save(function(err) {
      if (err) {
        return res.json({success: false, msg: 'id season node already exists.'});
      }

      var options = {
        port: CONSTANT.MQTT.PORT,
        clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
        username: CONSTANT.MQTT.USER,
        password: CONSTANT.MQTT.PASSWORD,
      };
      global.client= mqtt.connect("mqtt://" +CONSTANT.MQTT.SERVER, options);
      client.on('connect', function() {
                //subscribe thong tin moi truong.
                console.log(req.body.macPi +" =>>test"); 
                client.publish('seasonNode_', JSON.stringify(seasonNode), function() {
                  console.log("seasonNode_ is published");
                  client.end(); 
                });
              });
      res.json({success: true, msg: 'Successful created new sensor node.'});
    });
  }
});

  //create a new sensornode node (POST http://localhost:8080/api/add/snode)
  apiRoutes.post('/add/snode', function(req, res) {
    if (
     // !req.body.active ||  
      !req.body.sensor_id || 
      !req.body.macPi
      ) {
      console.log('sNode router user:', req.body);
      res.json({success: false, msg: 'Please to try again.'});
  } else {
    var sNode = new SNode({
      //active:req.body.active, 
        macPi:req.body.macPi,
       sensor_id:req.body.sensor_id,
       //_id: req.body.sensor_id
     });
    console.log('sNode router user:', sNode);
    sNode.save(function(err) {
      if (err) {
        return  res.redirect('/add/sensor/?status=false');
      }

      var options = {
        port: CONSTANT.MQTT.PORT,
        clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
        username: CONSTANT.MQTT.USER,
        password: CONSTANT.MQTT.PASSWORD,
      };
      global.client= mqtt.connect("mqtt://" +CONSTANT.MQTT.SERVER, options);
      client.on('connect', function() {
        //subscribe thong tin moi truong.
        console.log('sNode: ', sNode);
        console.log(req.body.macPi +" =>>test"); 
        client.publish('SNode_', JSON.stringify(sNode), function() {
        console.log("SNode_ is published");
          client.end(); 
        });
      });
      res.redirect('/add/sensor/?status=true');
    });
  }
});


  apiRoutes.post('/authenticate', function(req, res) {
    var incomingToken = req.headers;    
    console.log(incomingToken);
    User.findOne({
      name: req.body.uname
    }, function(err, user) {
      if (err) throw err;

      if (!user) {
        res.send({success: false, msg: 'Authentication failed. User not found.'});
      } else {
        console.log("user: ",user);
         // check if password matches
         user.comparePassword(req.body.psw, function (err, isMatch) {
          if (isMatch && !err) {
            // if user is found and password is right create a token
            var token = jwt.encode(user, config.secret);
            console.log("token: ",token);
            // return the information including token as JSON
            //select node for controller
            //var node = SensorNode.find({macPi:user.macPi})
            var data = {user,data};
            //expiresInMinutes: 1440 // expires in 24 hours
            res.render('home/index', { user:user } );
            //res.json({success: true, token: 'JWT ' + token});

          } else {
            res.send({success: false, msg: 'Authentication failed. Wrong password.'});
          }
        });
       }
     });
  });
  app.post('/login', passport.authenticate('signin', {
     successReturnToOrRedirect : '/home', 
     failureRedirect : '/login', 
     failureFlash : true 
  }));
  apiRoutes.get('/member',passport.authenticate('jwt',{session:false}),function(req,res){
    console.log("member");
    var token = getToken(req.headers);
    console.log(token);
    if(token){
      var decoded = jwt.decode(token, config.secret);
      User.findOne({
        name:decoded.name
      }, function(err, user){
        if (err) throw err;
        if (!user) {
          return res.status(403).send({success:false, msg : 'Authemtication failed. User not found.'});
        }else{
          return res.json({success:true, msg: 'Welcome in the member area ' + user+'!.'});            
        }
      })

    }else{
      return res.status(403).sen({success:false, msg:'No token provided'});

    }
  });
  getToken = function(headers) {
    if (headers && headers.authorization) {
      var parted = headers.authorization.split(' ');
      if (parted.length === 2) {
        return parted[1];
      }else {
        return null;
      }
    }
    else {
      return null;
    }
  }
  app.use('/api', apiRoutes);
}

function isLoggedIn(req, res, next) {

// nếu người dùng đã đăng nhập thì tiếp tục thực hiện
if (req.isAuthenticated())
 return next();

// ngược lại điều hướng về đăng nhập.
res.redirect('/login');
}