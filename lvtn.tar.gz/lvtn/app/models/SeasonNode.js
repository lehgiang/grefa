var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcrypt');

// Thanks to http://blog.matoski.com/articles/jwt-express-node-mongoose/

// set up a mongoose model
var SeasonNodeSchema = new Schema({
    
    active:{
        type: Boolean,
        //unique: false,
        required: true
    },
    active_start:{
        type: Date,
       // unique: true,
        //required: true
    },
    active_end: {
        type: Date,
        //unique: false,
        //required: true
    },
    name: {
        type: String,
        //unique: false,
        //required: true
    },
    season_id: { // mac_address_xbee
        type: String,
        //unique: false,
        required: true
    },
    _id: { // id season
        type: String,
        unique: true,
        required: true
    },
    macPi: { // mac_address raspberry
        type: String,
        //unique: false,
        //required: true
    }
   });

module.exports = mongoose.model('SeasonNode', SeasonNodeSchema);