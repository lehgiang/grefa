require('./global')
var express     = require('express');
var app         = express();
var bodyParser  = require('body-parser');
var morgan      = require('morgan');
var mongoose    = require('mongoose');
var passport	= require('passport');
var config      = require('./configs/database'); // get db config file
var port        = process.env.PORT || 8080;
var jwt         = require('jwt-simple');
var fs 			= require('fs');
var mqtt 		= require('mqtt');
var http		= require('http');
var socketio 	= require('socket.io');

var session = require('express-session');

//...


app.use(session({ cookie: { maxAge: 36000000 }, 
                  secret: 'woot',
                  resave: false, 
                  saveUninitialized: false}));

var flash = require('connect-flash');
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

// get our request parameters
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//templates
app.use(express.static("public/"))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', __views)

//socket
var server = http.createServer(app)
global.io = socketio.listen(server);

// log to console
app.use(morgan('dev'));
 
// demo Route (GET http://localhost:8080)
app.get('/', function(req, res) {
  res.send('Hello! The API is at http://localhost:' + port + '/api');
});
 
// Start the server
server.listen(port);
console.log('SERVER: http://localhost:' + port);

// connect to database
mongoose.connect(config.database);
mongoose.connection.on('connected',()=>{
	console.log('Mongoose connected to: ' + config.database);
});
mongoose.connection.on('error', (err) => {
  console.log('Mongoose connection error: ' + err)
});
mongoose.connection.on('disconnected', () => {
  console.log('Mongoose connection disconnected')
});


/* Set route */
fs.readdirSync(__routes).forEach(route => {
  require(__routes + route)(app)
});


/*Connect to MQTT*/
var options = {
  port: CONSTANT.MQTT.PORT,
  clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
  username: CONSTANT.MQTT.USER,
  password: CONSTANT.MQTT.PASSWORD,
};

// Create a client connection
global.client = mqtt.connect("mqtt://" +CONSTANT.MQTT.SERVER, options);

client.on('connect', function() {
    //subscribe thong tin moi truong.
    client.subscribe('smf_data');
    client.subscribe('test');
    client.subscribe('trangthaimaybom');
    client.publish('hello/world', 'my message', function() {
        console.log("Message is published");

    });

    client.on('message', function(topic, message, packet) {
        if (topic == "smf_data") {
           // var io = global.socketIO;
          io.sockets.emit('test', String(message));

          io.sockets.emit('smf_data_'+JSON.parse(message).macPi, String(message));
          console.log('smf_data_'+JSON.parse(message).macPi+":  " + message);

        }

        if (topic == "test") {
            console.log("test: " + message);
            //var io = global.socketIO;
            //io.sockets.emit('msg', String(message));

        }
        if (topic == "trangthaimaybom") {
            console.log("Nhan trang thai may bom: " + message);
            //var io = global.socketIO;
            //io.sockets.emit('msg', String(message));
            console.log("sent dddata !")

        }
    });


});