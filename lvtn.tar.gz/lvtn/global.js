global.__config = __dirname + '/configs/';
global.__server = __dirname + '/app/';
console.log(__config);
global.__controllers = __server + 'controllers/';
global.__services = __server + 'services/';
global.__models = __server + 'models/';
global.__views = __server + 'views/';
global.__routes = __server + 'routes/';
global.__modules = __server + 'modules/';
global.__prototype = __dirname + '/prototypes/';
global.__exts = __dirname + '/exts/';
global.__templates = __dirname + '/templates/';
global.__root = __dirname;
/* config, const */
global.CONSTANT = require(__config+'constant');
// global.ROUTE = CONSTANT.ROUTE;
//global.CONFIG = require(__config)
/* modules */

/* variables */

/* function */
global.isEmptyObject = function (obj) {
    return !Object.keys(obj).length;
}